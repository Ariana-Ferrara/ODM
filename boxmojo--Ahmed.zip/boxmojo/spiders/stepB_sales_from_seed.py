# boxmojo/spiders/stepB_sales_from_seed.py
# Step B (Scrapy): Read seed JSONL from Step A and scrape BoxOfficeMojo sales/title pages

import json
import re
from datetime import datetime
from urllib.parse import quote_plus

import scrapy
from boxmojo.items import SalesItem


# ----------------------------
# Helpers
# ----------------------------
def norm_ws(s: str) -> str:
    return " ".join(s.split()).strip() if s else ""


def money_to_int(text: str):
    """
    Handles:
      "$245,000,000" -> 245000000
      "$245 million" -> 245000000
      "$1.2 billion" -> 1200000000
    """
    if not text:
        return None

    t = norm_ws(text).lower()

    m = re.search(r"\$\s*([\d,]+)", t)
    if m:
        return int(m.group(1).replace(",", ""))

    m = re.search(r"\$\s*([\d]+(?:\.[\d]+)?)\s*(million|billion)", t)
    if m:
        val = float(m.group(1))
        mult = 1_000_000 if m.group(2) == "million" else 1_000_000_000
        return int(val * mult)

    return None


def extract_gross(text: str, label: str):
    """
    Pull totals from the 'All Releases' performance summary.
    """
    if not text:
        return None

    # With percent: DOMESTIC (45.2%) $123,456,789
    m = re.search(
        rf"{label}\s*\(\s*[\d.]+\s*%\s*\)\s*\$([\d,]+)",
        text,
        re.IGNORECASE,
    )
    if m:
        return int(m.group(1).replace(",", ""))

    # Without percent: WORLDWIDE $123,456,789
    m = re.search(rf"{label}\s*\$([\d,]+)", text, re.IGNORECASE)
    if m:
        return int(m.group(1).replace(",", ""))

    return None


def parse_runtime_minutes(rt: str):
    if not rt:
        return None
    rt = norm_ws(rt)
    hrs = re.search(r"(\d+)\s*hr", rt, re.IGNORECASE)
    mins = re.search(r"(\d+)\s*min", rt, re.IGNORECASE)
    h = int(hrs.group(1)) if hrs else 0
    m = int(mins.group(1)) if mins else 0
    total = h * 60 + m
    return total if total > 0 else None


def parse_release_date_to_date(s: str):
    """
    Parses "Jan 3, 2023" / "January 3, 2023" and ignores "(...)"
    """
    if not s:
        return None
    s = norm_ws(s).split("(")[0].strip()
    for fmt in ("%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


# ----------------------------
# Spider (Step B)
# ----------------------------
class MojoSalesFromSeedSpider(scrapy.Spider):
    name = "boxmojo_sales_from_seed"
    allowed_domains = ["boxofficemojo.com", "www.boxofficemojo.com"]

    custom_settings = {
        "DOWNLOAD_DELAY": 1.25,
        "AUTOTHROTTLE_ENABLED": True,
        "CONCURRENT_REQUESTS_PER_DOMAIN": 2,
        "ROBOTSTXT_OBEY": False,
        "USER_AGENT": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "DEFAULT_REQUEST_HEADERS": {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.8",
        },
    }

    def __init__(self, seed_path="seed_1980_2025.jsonl", start_date=None, end_date=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seed_path = seed_path
        self.start_date = datetime.strptime(start_date, "%Y-%m-%d").date() if start_date else None
        self.end_date = datetime.strptime(end_date, "%Y-%m-%d").date() if end_date else None

    def start_requests(self):
        """
        Read JSONL seed file line-by-line:
          {"title": "...", "year": 2010}
        Then search on BoxOfficeMojo and follow best match.
        """
        proxy = self.settings.get("BRIGHT_PROXY")  # optional, if you use it

        with open(self.seed_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                row = json.loads(line)
                title = row.get("title")
                year = row.get("year")

                if not title:
                    continue

                q = quote_plus(title)
                search_url = f"https://www.boxofficemojo.com/search/?q={q}"

                yield scrapy.Request(
                    url=search_url,
                    callback=self.parse_search,
                    meta={
                        "input_title": title,
                        "input_year": year,
                        "proxy": proxy,
                    },
                    dont_filter=True,
                )

    def parse_search(self, response):
        input_title = response.meta.get("input_title")
        input_year = response.meta.get("input_year")
        proxy = response.meta.get("proxy")

        candidates = []
        for a in response.css('a[href^="/title/tt"]'):
            href = a.attrib.get("href")
            if not href:
                continue

            anchor_title = norm_ws(" ".join(a.css("::text").getall()))
            block = a.xpath("ancestor::div[1]")
            block_text = norm_ws(" ".join(block.css("::text").getall()))

            candidates.append(
                {"href": href, "anchor_title": anchor_title, "block_text": block_text}
            )

        if not candidates:
            yield SalesItem(
                input_title=input_title,
                input_year=input_year,
                bom_title=None,
                budget=None,
                opening_weekend=None,
                gross_worldwide=None,
                gross_domestic=None,
                gross_international=None,
                release_date=None,
                genres=None,
                runtime_minutes=None,
                filmmakers=None,
                cast=None,
                source_url=None,
            )
            return

        best = None
        if input_year:
            y = str(input_year)
            for c in candidates:
                if f"({y})" in c["block_text"]:
                    best = c
                    break

        if not best:
            best = candidates[0]

        title_url = response.urljoin(best["href"].split("?")[0].rstrip("/") + "/")

        yield scrapy.Request(
            url=title_url,
            callback=self.parse_title,
            meta={
                "input_title": input_title,
                "input_year": input_year,
                "proxy": proxy,
            },
            dont_filter=True,
        )

    def parse_title(self, response):
        input_title = response.meta.get("input_title")
        input_year = response.meta.get("input_year")
        proxy = response.meta.get("proxy")

        bom_title = norm_ws(response.css("h1::text").get())

        # A) summary key-values
        info = {}
        for row in response.css("div.mojo-summary-values div.a-section.a-spacing-none"):
            spans = [norm_ws(s) for s in row.css("span::text").getall() if s and s.strip()]
            if len(spans) >= 2:
                label = spans[0].rstrip(":").strip()
                value = spans[1].strip()
                if label and value:
                    info[label] = value

        # fallback
        if not info:
            for row in response.css("div.a-section.a-spacing-none"):
                spans = [norm_ws(s) for s in row.css("span::text").getall() if s and s.strip()]
                if len(spans) >= 2:
                    label = spans[0].rstrip(":").strip()
                    value = spans[1].strip()
                    if label and value and label in {
                        "Budget", "Domestic Opening", "Earliest Release Date", "Release Date",
                        "Domestic Release Date", "Running Time", "Runtime", "Genres"
                    }:
                        info[label] = value

        # B) all releases summary text
        summary_text = norm_ws(" ".join(
            t.strip() for t in response.css("div.mojo-performance-summary *::text").getall()
            if t and t.strip()
        ))

        if not summary_text:
            summary_text = norm_ws(" ".join(
                t.strip() for t in response.css("body *::text").getall()
                if t and t.strip()
            ))

        gross_domestic = extract_gross(summary_text, "Domestic")
        gross_international = extract_gross(summary_text, "International")
        gross_worldwide = extract_gross(summary_text, "Worldwide")

        budget = money_to_int(info.get("Budget"))
        opening_weekend = money_to_int(info.get("Domestic Opening"))

        release_date = (
            info.get("Release Date")
            or info.get("Earliest Release Date")
            or info.get("Domestic Release Date")
        )
        release_date = norm_ws(release_date) if release_date else None

        # optional date window filtering (if you use it)
        rd = parse_release_date_to_date(release_date)
        if self.start_date and rd and rd < self.start_date:
            return
        if self.end_date and rd and rd > self.end_date:
            return

        genres = norm_ws(info.get("Genres")) if info.get("Genres") else None
        runtime_minutes = parse_runtime_minutes(info.get("Running Time") or info.get("Runtime"))

        item = SalesItem(
            input_title=input_title,
            input_year=input_year,
            bom_title=bom_title or None,
            budget=budget,
            opening_weekend=opening_weekend,
            gross_worldwide=gross_worldwide,
            gross_domestic=gross_domestic,
            gross_international=gross_international,
            release_date=release_date,
            genres=genres,
            runtime_minutes=runtime_minutes,
            filmmakers=None,
            cast=None,
            source_url=response.url,
        )

        credits_url = response.url.split("?")[0].rstrip("/") + "/credits/"
        yield scrapy.Request(
            url=credits_url,
            callback=self.parse_credits,
            meta={"item": item, "proxy": proxy},
            dont_filter=True,
        )

    def parse_credits(self, response):
        item = response.meta["item"]

        filmmakers = []
        cast = []

        for tr in response.css("table tr"):
            tds = tr.css("td")
            if len(tds) < 2:
                continue

            left = norm_ws(" ".join(tds[0].css("::text").getall()))
            right = norm_ws(" ".join(tds[1].css("::text").getall()))
            if not left or not right:
                continue

            filmmakers.append({"name": left, "role": right})
            cast.append({"actor": left, "role": right})

        def dedupe(lst, keys):
            seen = set()
            out = []
            for d in lst:
                k = tuple(d.get(x) for x in keys)
                if k in seen:
                    continue
                seen.add(k)
                out.append(d)
            return out

        item["filmmakers"] = dedupe(filmmakers, ("name", "role")) or None
        item["cast"] = dedupe(cast, ("actor", "role")) or None

        yield item
