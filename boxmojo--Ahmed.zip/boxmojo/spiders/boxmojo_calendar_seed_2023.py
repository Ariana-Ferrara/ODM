# boxmojo/spiders/boxmojo_calendar_seed_2023.py
# Build a SEED file from BoxOfficeMojo calendar pages (2023)

import re
from datetime import date, datetime

import scrapy
from dateutil.relativedelta import relativedelta


def norm_ws(s: str) -> str:
    return " ".join(s.split()).strip() if s else ""


def parse_release_header_to_date(s: str):
    """
    Calendar pages sometimes show headers like:
      'January 19, 2023'
    We parse those into a date object.
    """
    if not s:
        return None
    s = norm_ws(s)
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


class BoxMojoCalendarSeedSpider(scrapy.Spider):
    """
    Seed builder spider (CALENDAR MODE):
    - Crawls BoxOfficeMojo calendar pages (monthly)
    - Extracts release links (/release/rl...) and visits them
    - Emits seed lines: {"title": "...", "year": 2023}
    """
    name = "boxmojo_calendar_seed"
    allowed_domains = ["boxofficemojo.com", "www.boxofficemojo.com"]

    custom_settings = {
        "DOWNLOAD_DELAY": 1.25,
        "AUTOTHROTTLE_ENABLED": True,
        "CONCURRENT_REQUESTS_PER_DOMAIN": 2,
        "ROBOTSTXT_OBEY": False,
        "USER_AGENT": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "DEFAULT_REQUEST_HEADERS": {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.8",
        },
    }

    def __init__(self, start_date="2023-01-01", end_date="2023-12-30", *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_date = date.fromisoformat(start_date)
        self.end_date = date.fromisoformat(end_date)
        self.seen_tt = set()

    def _proxy_meta(self):
        """
        Safe proxy injection:
        Only add meta['proxy'] if BRIGHT_PROXY is defined in settings.
        """
        proxy = self.settings.get("BRIGHT_PROXY")
        return {"proxy": proxy} if proxy else {}

    async def start(self):
        d = date(self.start_date.year, self.start_date.month, 1)
        end_month = date(self.end_date.year, self.end_date.month, 1)

        base_meta = self._proxy_meta()

        while d <= end_month:
            url = f"https://www.boxofficemojo.com/calendar/{d:%Y-%m-01}/"
            meta = {**base_meta, "calendar_month": f"{d:%Y-%m}"}

            yield scrapy.Request(
                url=url,
                callback=self.parse_calendar,
                meta=meta,
                dont_filter=True,
            )
            d += relativedelta(months=1)

    def parse_calendar(self, response):
        """
        Calendar page: follow release pages (best coverage),
        and fallback to direct title pages if present.
        """
        release_links = response.css('a[href^="/release/rl"]::attr(href)').getall()
        title_links = response.css('a[href^="/title/tt"]::attr(href)').getall()

        if not release_links and not title_links:
            self.logger.warning("No release/title links found on: %s", response.url)
            return

        month_year = response.meta.get("calendar_month")  # "YYYY-MM"
        base_meta = self._proxy_meta()

        # Follow release links
        for href in release_links:
            if not href:
                continue
            url = response.urljoin(href.split("?")[0])
            meta = {**base_meta, "calendar_month": month_year}

            yield scrapy.Request(
                url=url,
                callback=self.parse_release_page,
                meta=meta,
                dont_filter=True,
            )

        # Follow direct title links (extra coverage)
        for href in title_links:
            if not href:
                continue
            url = response.urljoin(href.split("?")[0])
            meta = {**base_meta, "calendar_month": month_year}

            yield scrapy.Request(
                url=url,
                callback=self.parse_title_page,
                meta=meta,
                dont_filter=True,
            )

    def parse_release_page(self, response):
        """
        Release page usually contains a link to /title/ttXXXXXXX/
        We'll extract title + tt-id from there.
        """
        href = response.css('a[href^="/title/tt"]::attr(href)').get()
        if not href:
            return

        clean = href.split("?")[0].rstrip("/") + "/"
        m = re.search(r"/title/(tt\d+)/", clean)
        if not m:
            return

        tt_id = m.group(1)
        if tt_id in self.seen_tt:
            return
        self.seen_tt.add(tt_id)

        title = norm_ws(response.css("h1 a::text").get() or response.css("h1::text").get())
        if not title:
            title = norm_ws(response.css('a[href^="/title/tt"]::text').get())

        if not title:
            return

        out_year = self._infer_year(response)
        if out_year is None:
            out_year = int(response.meta["calendar_month"][:4])

        yield {"title": title, "year": out_year}

    def parse_title_page(self, response):
        """
        Title page fallback: grab h1 and infer year from calendar month.
        Also dedupe by tt-id from URL.
        """
        m = re.search(r"/title/(tt\d+)/", response.url)
        if not m:
            return

        tt_id = m.group(1)
        if tt_id in self.seen_tt:
            return
        self.seen_tt.add(tt_id)

        title = norm_ws(response.css("h1::text").get())
        if not title:
            return

        out_year = int(response.meta["calendar_month"][:4])
        yield {"title": title, "year": out_year}

    def _infer_year(self, response):
        """
        Try to infer year from a nearby release date header on the page.
        If not found, return None and we fallback to calendar_month.
        """
        possible = response.xpath("//h2/text() | //h3/text() | //h4/text()").getall()
        for t in possible:
            dt = parse_release_header_to_date(t)
            if dt and (self.start_date <= dt <= self.end_date):
                return int(dt.year)
        return None