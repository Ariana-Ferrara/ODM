# boxmojo/spiders/stepA_selenium_calendar_seed.py
# Step A (Selenium): Build seed_2023.jsonl from BoxOfficeMojo calendar pages (2023)
#
# Default: 2023 only
# Run all calendar months across years with: --all --start-year YYYY --end-year YYYY
#
# Output JSONL lines:
#   {"title": "...", "year": 2023}

import argparse
import json
import re
import time
from datetime import date
from typing import Dict, List, Optional, Set, Tuple

from dateutil.relativedelta import relativedelta

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# Auto-manage ChromeDriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service


# -------------------------
# Helpers
# -------------------------
def norm_ws(s: str) -> str:
    return " ".join(s.split()).strip() if s else ""


def month_iter(start_dt: date, end_dt: date):
    d = date(start_dt.year, start_dt.month, 1)
    end_month = date(end_dt.year, end_dt.month, 1)
    while d <= end_month:
        yield d
        d += relativedelta(months=1)


def clean_href(href: str) -> str:
    return (href or "").split("?")[0]


def extract_tt_id(url: str) -> Optional[str]:
    if not url:
        return None
    m = re.search(r"/title/(tt\d+)/", url)
    return m.group(1) if m else None


def safe_text(el) -> str:
    try:
        return el.text or ""
    except Exception:
        return ""


def build_driver(headless: bool, page_load_timeout: int) -> webdriver.Chrome:
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--window-size=1400,900")
    opts.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )

    #  webdriver-manager provides the correct driver automatically
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=opts)
    driver.set_page_load_timeout(page_load_timeout)
    return driver


def fetch_calendar_links(driver: webdriver.Chrome, cal_url: str, wait_sec: float) -> Tuple[List[str], List[str]]:
    driver.get(cal_url)
    time.sleep(wait_sec)

    a_tags = driver.find_elements(By.CSS_SELECTOR, "a[href]")
    release_links: List[str] = []
    title_links: List[str] = []

    for a in a_tags:
        href = clean_href(a.get_attribute("href") or "")
        if not href or "boxofficemojo.com" not in href:
            continue
        if "/release/rl" in href:
            release_links.append(href)
        elif "/title/tt" in href:
            title_links.append(href)

    def dedupe_keep_order(xs: List[str]) -> List[str]:
        seen = set()
        out = []
        for x in xs:
            if x in seen:
                continue
            seen.add(x)
            out.append(x)
        return out

    return dedupe_keep_order(release_links), dedupe_keep_order(title_links)


def resolve_release_to_title(driver: webdriver.Chrome, release_url: str, wait_sec: float) -> Optional[Dict]:
    try:
        driver.get(release_url)
        time.sleep(wait_sec)
    except Exception:
        return None

    try:
        title_a = driver.find_element(By.CSS_SELECTOR, 'a[href*="/title/tt"]')
        href = clean_href(title_a.get_attribute("href") or "")
        tt = extract_tt_id(href)
        if not tt:
            return None
    except Exception:
        return None

    title_text = ""
    try:
        h1a = driver.find_element(By.CSS_SELECTOR, "h1 a")
        title_text = norm_ws(safe_text(h1a))
    except Exception:
        pass

    if not title_text:
        try:
            h1 = driver.find_element(By.CSS_SELECTOR, "h1")
            title_text = norm_ws(safe_text(h1))
        except Exception:
            pass

    if not title_text:
        title_text = norm_ws(safe_text(title_a))

    if not title_text:
        return None

    return {"tt": tt, "title": title_text}


def resolve_title_page(driver: webdriver.Chrome, title_url: str, wait_sec: float) -> Optional[Dict]:
    tt = extract_tt_id(title_url)
    if not tt:
        return None

    try:
        driver.get(title_url)
        time.sleep(wait_sec)
    except Exception:
        return None

    try:
        h1 = driver.find_element(By.CSS_SELECTOR, "h1")
        title_text = norm_ws(safe_text(h1))
    except Exception:
        return None

    if not title_text:
        return None

    return {"tt": tt, "title": title_text}


# -------------------------
# Main
# -------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="seed_2023.jsonl", help="Output JSONL file name")
    ap.add_argument("--headless", action="store_true", help="Run Chrome headless")
    ap.add_argument("--wait", type=float, default=2.0, help="Seconds to wait after each page load")
    ap.add_argument("--timeout", type=int, default=60, help="Page load timeout (seconds)")

    ap.add_argument("--all", action="store_true", help="Scrape ALL calendar months between start-year and end-year")
    ap.add_argument("--start-year", type=int, default=2023, help="Start year (used with --all)")
    ap.add_argument("--end-year", type=int, default=2023, help="End year (used with --all)")

    #  streaming write (safer for long runs / Ctrl+C / internet drop)
    ap.add_argument("--append", action="store_true", help="Append to output instead of overwriting")

    args = ap.parse_args()

    if args.all:
        start_date = date(args.start_year, 1, 1)
        end_date = date(args.end_year, 12, 31)
    else:
        start_date = date(2023, 1, 1)
        end_date = date(2023, 12, 31)

    driver = build_driver(headless=args.headless, page_load_timeout=args.timeout)

    # Dedup within run:
    seen_tt: Set[str] = set()
    # Extra safety: dedupe on (title, year) too (useful if tt missing somewhere)
    seen_title_year: Set[Tuple[str, int]] = set()

    mode = "a" if args.append else "w"

    written = 0
    try:
        with open(args.out, mode, encoding="utf-8") as f:
            for d in month_iter(start_date, end_date):
                cal_url = f"https://www.boxofficemojo.com/calendar/{d:%Y-%m-01}/"
                print(f"[calendar] {d:%Y-%m} -> {cal_url}")

                release_links, title_links = fetch_calendar_links(driver, cal_url, args.wait)

                # 1) Preferred: resolve release -> title
                for rl in release_links:
                    rec = resolve_release_to_title(driver, rl, args.wait)
                    if not rec:
                        continue

                    tt = rec.get("tt")
                    title = rec.get("title", "")
                    year = int(d.year)

                    key = (title.lower(), year)

                    if tt and tt in seen_tt:
                        continue
                    if key in seen_title_year:
                        continue

                    if tt:
                        seen_tt.add(tt)
                    seen_title_year.add(key)

                    f.write(json.dumps({"title": title, "year": year}, ensure_ascii=False) + "\n")
                    f.flush()
                    written += 1

                # 2) Fallback: visit title pages directly
                for tu in title_links:
                    rec = resolve_title_page(driver, tu, args.wait)
                    if not rec:
                        continue

                    tt = rec.get("tt")
                    title = rec.get("title", "")
                    year = int(d.year)

                    key = (title.lower(), year)

                    if tt and tt in seen_tt:
                        continue
                    if key in seen_title_year:
                        continue

                    if tt:
                        seen_tt.add(tt)
                    seen_title_year.add(key)

                    f.write(json.dumps({"title": title, "year": year}, ensure_ascii=False) + "\n")
                    f.flush()
                    written += 1

    finally:
        try:
            driver.quit()
        except Exception:
            pass

    print(f"\n wrote {written} NEW rows to: {args.out}")


if __name__ == "__main__":
    main()