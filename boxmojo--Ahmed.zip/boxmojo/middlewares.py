# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import base64
from scrapy import signals

# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class BoxmojoSpiderMiddleware:
    @classmethod
    def from_crawler(cls, crawler):
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        return None

    def process_spider_output(self, response, result, spider):
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        pass

    async def process_start(self, start):
        async for item_or_request in start:
            yield item_or_request

    def spider_opened(self, spider):
        spider.logger.info("Spider opened: %s", spider.name)


class BoxmojoDownloaderMiddleware:
    @classmethod
    def from_crawler(cls, crawler):
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        return None

    def process_response(self, request, response, spider):
        return response

    def process_exception(self, request, exception, spider):
        pass

    def spider_opened(self, spider):
        spider.logger.info("Spider opened: %s", spider.name)


# -------------------------------------------------------------------
# Bright Data Proxy Middleware (DOWNLOADER middleware)
# -------------------------------------------------------------------
class BrightDataProxyMiddleware:
    """
    Forces all requests through Bright Data (HTTP proxy + basic auth).

    settings.py must include:
      BRIGHTDATA_PROXY_URL = "http://brd.superproxy.io:33335"
      BRIGHTDATA_USERNAME = "brd-customer-..."
      BRIGHTDATA_PASSWORD = "..."
    """

    def __init__(self, proxy_url: str, username: str, password: str):
        self.proxy_url = proxy_url
        if username and password:
            token = f"{username}:{password}".encode("utf-8")
            self.auth_header = b"Basic " + base64.b64encode(token)
        else:
            self.auth_header = None

    @classmethod
    def from_crawler(cls, crawler):
        s = crawler.settings
        return cls(
            proxy_url=s.get("BRIGHTDATA_PROXY_URL"),
            username=s.get("BRIGHTDATA_USERNAME"),
            password=s.get("BRIGHTDATA_PASSWORD"),
        )

    def process_request(self, request, spider):
        if not self.proxy_url:
            return None

        request.meta["proxy"] = self.proxy_url

        # Bright Data requires Proxy-Authorization for username/password auth
        if self.auth_header:
            request.headers["Proxy-Authorization"] = self.auth_header

        # Optional: quick proof in logs (comment out once confirmed)
        spider.logger.info("Proxy ON -> %s %s", self.proxy_url, request.url)

        return None




# # Define here the models for your spider middleware
# #
# # See documentation in:
# # https://docs.scrapy.org/en/latest/topics/spider-middleware.html

# from scrapy import signals

# # useful for handling different item types with a single interface
# from itemadapter import ItemAdapter


# class BoxmojoSpiderMiddleware:
#     # Not all methods need to be defined. If a method is not defined,
#     # scrapy acts as if the spider middleware does not modify the
#     # passed objects.

#     @classmethod
#     def from_crawler(cls, crawler):
#         # This method is used by Scrapy to create your spiders.
#         s = cls()
#         crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
#         return s

#     def process_spider_input(self, response, spider):
#         # Called for each response that goes through the spider
#         # middleware and into the spider.

#         # Should return None or raise an exception.
#         return None

#     def process_spider_output(self, response, result, spider):
#         # Called with the results returned from the Spider, after
#         # it has processed the response.

#         # Must return an iterable of Request, or item objects.
#         for i in result:
#             yield i

#     def process_spider_exception(self, response, exception, spider):
#         # Called when a spider or process_spider_input() method
#         # (from other spider middleware) raises an exception.

#         # Should return either None or an iterable of Request or item objects.
#         pass

#     async def process_start(self, start):
#         # Called with an async iterator over the spider start() method or the
#         # matching method of an earlier spider middleware.
#         async for item_or_request in start:
#             yield item_or_request

#     def spider_opened(self, spider):
#         spider.logger.info("Spider opened: %s" % spider.name)


# class BoxmojoDownloaderMiddleware:
#     # Not all methods need to be defined. If a method is not defined,
#     # scrapy acts as if the downloader middleware does not modify the
#     # passed objects.

#     @classmethod
#     def from_crawler(cls, crawler):
#         # This method is used by Scrapy to create your spiders.
#         s = cls()
#         crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
#         return s

#     def process_request(self, request, spider):
#         # Called for each request that goes through the downloader
#         # middleware.

#         # Must either:
#         # - return None: continue processing this request
#         # - or return a Response object
#         # - or return a Request object
#         # - or raise IgnoreRequest: process_exception() methods of
#         #   installed downloader middleware will be called
#         return None

#     def process_response(self, request, response, spider):
#         # Called with the response returned from the downloader.

#         # Must either;
#         # - return a Response object
#         # - return a Request object
#         # - or raise IgnoreRequest
#         return response

#     def process_exception(self, request, exception, spider):
#         # Called when a download handler or a process_request()
#         # (from other downloader middleware) raises an exception.

#         # Must either:
#         # - return None: continue processing this exception
#         # - return a Response object: stops process_exception() chain
#         # - return a Request object: stops process_exception() chain
#         pass

#     def spider_opened(self, spider):
#         spider.logger.info("Spider opened: %s" % spider.name)
