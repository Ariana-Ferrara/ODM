# Scrapy settings for boxmojo project

BOT_NAME = "boxmojo"

SPIDER_MODULES = ["boxmojo.spiders"]
NEWSPIDER_MODULE = "boxmojo.spiders"

ADDONS = {}

# BoxOfficeMojo: usually keep robots off for assignment crawling
ROBOTSTXT_OBEY = False

# Polite crawling
CONCURRENT_REQUESTS_PER_DOMAIN = 1
DOWNLOAD_DELAY = 1
AUTOTHROTTLE_ENABLED = True

FEED_EXPORT_ENCODING = "utf-8"

# ---------------------------
# Bright Data Proxy (Scrapy)
# ---------------------------
# NOTE: rotate these credentials later (don’t keep secrets in code).
BRIGHT_PROXY = "http://brd-customer-hl_79cc5ce7-zone-proxygroup1:lv505da0ax0k@brd.superproxy.io:33335"

# If your middleware uses these three instead of BRIGHT_PROXY, keep them too:
BRIGHTDATA_PROXY_URL = "http://brd.superproxy.io:33335"
BRIGHTDATA_USERNAME = "brd-customer-hl_79cc5ce7-zone-proxygroup1"
BRIGHTDATA_PASSWORD = "lv505da0ax0k"

DOWNLOADER_MIDDLEWARES = {
    # your custom middleware should set request.meta["proxy"]
    "boxmojo.middlewares.BrightDataProxyMiddleware": 350,
    "scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware": 400,
}

# ---------------------------
# Pipelines
# ---------------------------
ITEM_PIPELINES = {
    "boxmojo.pipelines.CleanSalesPipeline": 300,
}

# ---------------------------
# IMPORTANT: Disable Playwright
# ---------------------------
# Remove / comment these to avoid:
# "Unsupported URL scheme 'https': No module named scrapy_playwright"
#
# DOWNLOAD_HANDLERS = {
#     "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
#     "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
# }
# TWISTED_REACTOR = "twisted.internet.asyncioreactor.AsyncioSelectorReactor"
# PLAYWRIGHT_LAUNCH_OPTIONS = {
#     "proxy": {
#         "server": "http://brd.superproxy.io:33335",
#         "username": "...",
#         "password": "...",
#     }
# }



# # Scrapy settings for boxmojo project
# #
# # For simplicity, this file contains only settings considered important or
# # commonly used. You can find more settings consulting the documentation:
# #
# #     https://docs.scrapy.org/en/latest/topics/settings.html
# #     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
# #     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

# BOT_NAME = "boxmojo"

# SPIDER_MODULES = ["boxmojo.spiders"]
# NEWSPIDER_MODULE = "boxmojo.spiders"

# ADDONS = {}


# # Crawl responsibly by identifying yourself (and your website) on the user-agent
# #USER_AGENT = "boxmojo (+http://www.yourdomain.com)"

# # Obey robots.txt rules
# ROBOTSTXT_OBEY = True

# # Concurrency and throttling settings
# #CONCURRENT_REQUESTS = 16
# CONCURRENT_REQUESTS_PER_DOMAIN = 1
# DOWNLOAD_DELAY = 1

# # Disable cookies (enabled by default)
# #COOKIES_ENABLED = False

# # Disable Telnet Console (enabled by default)
# #TELNETCONSOLE_ENABLED = False

# # Override the default request headers:
# #DEFAULT_REQUEST_HEADERS = {
# #    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
# #    "Accept-Language": "en",
# #}

# # Enable or disable spider middlewares
# # See https://docs.scrapy.org/en/latest/topics/spider-middleware.html
# #SPIDER_MIDDLEWARES = {
# #    "boxmojo.middlewares.BoxmojoSpiderMiddleware": 543,
# #}

# # Enable or disable downloader middlewares
# # See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html

# ############################################################################################aaddd my opwn proxy later#######
# DOWNLOADER_MIDDLEWARES = {
#     'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 400,
# }

# #--- working from stefan
# #custom proxy string
# PLAYWRIGHT_LAUNCH_OPTIONS = {
#        'proxy': {
#            'server': 'http://brd.superproxy.io:33335',
#            'username': 'brd-customer-hl_79cc5ce7-zone-proxygroup1',
#            'password': 'lv505da0ax0k',
#        }
#    }


# #--- current one (not working)
# # HTTP_PROXY = "http://brd-customer-hl_79cc5ce7-zone-proxygroup1:lv505da0ax0k@brd.superproxy.io:33335"

# ### Ahmed --------------------
# ITEM_PIPELINES = {
#     "boxmojo.pipelines.CleanSalesPipeline": 300,
# }



# #DOWNLOADER_MIDDLEWARES = {
# #    "boxmojo.middlewares.BoxmojoDownloaderMiddleware": 543,
# #}

# # Enable or disable extensions
# # See https://docs.scrapy.org/en/latest/topics/extensions.html
# #EXTENSIONS = {
# #    "scrapy.extensions.telnet.TelnetConsole": None,
# #}

# # Configure item pipelines
# # See https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# #ITEM_PIPELINES = {
# #    "boxmojo.pipelines.BoxmojoPipeline": 300,
# #}

# # Enable and configure the AutoThrottle extension (disabled by default)
# # See https://docs.scrapy.org/en/latest/topics/autothrottle.html
# #AUTOTHROTTLE_ENABLED = True
# # The initial download delay
# #AUTOTHROTTLE_START_DELAY = 5
# # The maximum download delay to be set in case of high latencies
# #AUTOTHROTTLE_MAX_DELAY = 60
# # The average number of requests Scrapy should be sending in parallel to
# # each remote server
# #AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# # Enable showing throttling stats for every response received:
# #AUTOTHROTTLE_DEBUG = False

# # Enable and configure HTTP caching (disabled by default)
# # See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
# #HTTPCACHE_ENABLED = True
# #HTTPCACHE_EXPIRATION_SECS = 0
# #HTTPCACHE_DIR = "httpcache"
# #HTTPCACHE_IGNORE_HTTP_CODES = []
# #HTTPCACHE_STORAGE = "scrapy.extensions.httpcache.FilesystemCacheStorage"

# # Set settings whose default value is deprecated to a future-proof value
# FEED_EXPORT_ENCODING = "utf-8"

# Scrapy settings for boxmojo project

# BOT_NAME = "boxmojo"

# SPIDER_MODULES = ["boxmojo.spiders"]
# NEWSPIDER_MODULE = "boxmojo.spiders"

# ADDONS = {}

# # For BoxOfficeMojo you typically want this OFF (unless your assignment requires robots obey)
# ROBOTSTXT_OBEY = False

# CONCURRENT_REQUESTS_PER_DOMAIN = 1
# DOWNLOAD_DELAY = 1

# FEED_EXPORT_ENCODING = "utf-8"

# # ---------------------------
# # Bright Data Proxy (Scrapy)
# # ---------------------------
# BRIGHTDATA_PROXY_URL = "http://brd.superproxy.io:33335"
# BRIGHTDATA_USERNAME = "brd-customer-hl_79cc5ce7-zone-proxygroup1"
# BRIGHTDATA_PASSWORD = "lv505da0ax0k"

# DOWNLOADER_MIDDLEWARES = {
#     "boxmojo.middlewares.BrightDataProxyMiddleware": 350,
#     "scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware": 400,
# }

# # ---------------------------
# # Pipelines
# # ---------------------------
# ITEM_PIPELINES = {
#     "boxmojo.pipelines.CleanSalesPipeline": 300,
# }


# #-------------- using Playwright
# DOWNLOAD_HANDLERS = {
#     "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
#     "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
# }

# TWISTED_REACTOR = "twisted.internet.asyncioreactor.AsyncioSelectorReactor"

# PLAYWRIGHT_LAUNCH_OPTIONS = {
#     "proxy": {
#         "server": "http://brd.superproxy.io:33335",
#         "username": "brd-customer-hl_79cc5ce7-zone-proxygroup1",
#         "password": "lv505da0ax0k",
#     }
# }




# # DOWNLOADER_MIDDLEWARES = {
# #     "boxmojo.middlewares.BrightDataProxyMiddleware": 350,
# #     "scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware": 400,
# # }

# # BRIGHTDATA_PROXY_URL = "http://brd.superproxy.io:33335"
# # BRIGHTDATA_USERNAME = "brd-customer-hl_79cc5ce7-zone-proxygroup1"
# # BRIGHTDATA_PASSWORD = "lv505da0ax0k"

