# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class BoxmojoPipeline:
    def process_item(self, item, spider):
        return item
###########################################################
#Ahmed-----------------
class CleanSalesPipeline:
    def process_item(self, item, spider):
        for field in ["budget", "opening_weekend", "gross_worldwide"]:
            val = item.get(field)
            if val in ["", "-", "N/A", None]:
                item[field] = None
        return item
